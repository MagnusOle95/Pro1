package guifx;

import javafx.application.Application;

public class App {

	public static void main(String[] args) {
		Application.launch(Interface.class);
	}

}
